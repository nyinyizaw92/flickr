const currentUser = (state = {}, action) => {
   
    switch(action.type){
        case 'LOGIN':
        console.log('actionuser',action.user)
            return action.user;
        default:
            return state;
    }
}


export default currentUser;