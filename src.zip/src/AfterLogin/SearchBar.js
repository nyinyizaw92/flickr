import React from 'react' 
import './search.css'
import {
    BrowserRouter as Router,
    Redirect,
    Route,
    Link
  } from "react-router-dom";
// import { Link } from 'react-router-dom'
import { NavLink } from 'react-router-dom'
import UploadImage from '../Components/Image/UploadImage'
import ArticleDetailList from '../Components/ArticleList/ArticleDetailList'
import ArticleList from '../Components/ArticleList/ArticleList'
import DeleteArticle from '../Components/ArticleList/DeleteArticle'
import SearchList from './SearchList'


class SearchBar extends React.Component{

    render(){
       
     
        return(
            <Router>
            <nav style={{padding:'20px',background:'#8A8888',color:'black',height:'80px'}}>
            <div class="nav-wrapper">
                <Link style={{color:'#DAD6D6'}} to='/home' class="brand-logo left">Home</Link>
                <ul id="nav-mobile" class="left hide-on-med-and-down">
                    
                    {/* <li><input type="text" style={search} placeholder="Search">
                    </input><button class="btn btn-sm btn-success">Search</button></li> */}
                  <li><SearchList/></li>
                </ul>
                <Link to='/upload' style={{color:'#DAD6D6',marginLeft:'20px',fontSize:'20px'}} class="brand-logo left">Upload</Link>
            </div>
         </nav>
   
     
        <Route path='/search' component={SearchBar} />
        <Route path='/upload' component={UploadImage}/>
       
        <ArticleList/>
       
       </Router>
     
        )
    }
}

export default SearchBar