import React from 'react'

class UploadFile extends React.Component{
    render(){
        return(
            <h1>Upload File</h1>
        )
    }
}

export default UploadFile