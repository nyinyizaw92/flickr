import React from 'react'
import './after.css'
import {
    BrowserRouter as Router,
    Switch,
    Redirect,
    Route,
    Link
  } from "react-router-dom";
import SearchBar from './SearchBar'


class Afterlogin extends React.Component{
    render(){
        return(
            <React.Fragment>
                <SearchBar />
               
            </React.Fragment>
        
             
        )
    }
}

export default Afterlogin