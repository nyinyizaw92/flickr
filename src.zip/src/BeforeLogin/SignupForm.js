import React from 'react'
import { connect } from 'react-redux'
import { insertUser } from '../Actions/UserActions'
import './form.css'

class SignupForm extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            username:'',
            email:'',
            password:'',
            confirm_password:'',
           
            completeRegister: false
        }
    
    }
   
    handleChange = (e) =>{
       this.setState({
            [e.target.id]:e.target.value,
          
       })
    }

    handleSubmit = (e) =>{
       e.preventDefault();
       console.log(this.state);
        if(this.state.password===this.state.confirm_password){
            this.props.insertUser(
                {
                    username:this.state.username,
                    email:this.state.email,
                    password:this.state.password,
                    
                },
                ()=>{
                    this.setState = (e) =>({
                        completeRegister:true,
                        [e.target.id]:'',
                    });
                }
            )
        }
    }

    render(){
        const color = {
            color:'#2BBFF5'
        }
        return(
            <form onSubmit={this.handleSubmit} class="form-control" style={{backgroundColor:'transparent',height:'300px',border:'0px'}}>
            <h5 style={{color:'white'}}>
                Sign Up
            </h5>
            <div className="input-field">
                <label htmlFor="username"  style={color}>Username</label>
                <input type="text" id="username" onChange={this.handleChange} required/>
            </div>
           
            <div className="input-field">
                <label htmlFor="email" style={color}>Email</label>
                <input type="email" id="email" onChange={this.handleChange} required/>
            </div>
            <div className="input-field">
                <label htmlFor="password"  style={color}>Password</label>
                <input type="password" id="password" onChange={this.handleChange} required/>
            </div>
            <div className="input-field">
                <label htmlFor="confirm_password"  style={color}>Confirm Password</label>
                <input type="password" id="confirm_password" onChange={this.handleChange} required/>
            </div>
        
            <div className="input-field">
                <button className="btn red lighten-1 z-depth" type="submit" >Sign Up</button>
            </div>
        </form>
        )
    }
}

//export default SignupForm
const mapDispatchToProps = {
    insertUser
}

export default  connect(null,mapDispatchToProps)(SignupForm)