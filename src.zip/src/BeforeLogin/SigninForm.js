import React from 'react'
import {
    Redirect,
 
  } from "react-router-dom";
import { connect } from "react-redux";
import { loginUserEvent,fetchUsers } from "../Actions/UserActions"
import  Afterlogin from '../AfterLogin/Afterlogin'

class SigninForm extends React.Component{
    constructor(props){
        super(props);
        this.state = {
           username:'',
            password:'',
            loginTrue:false,
           
        }
        this.props.fetchUsers();
    }

    handleChange = (e) =>{
       this.setState({
        [e.target.id] : e.target.value,
       })
    }

    handleSubmit = (e) =>{
        e.preventDefault()
     
        const username = this.state.username;
        const pass= this.state.password;
        console.log(username)
        const currentUser = this.props.users.find(user => user.username == username && user.password == pass);
          
            if(currentUser){
                this.props.loginUserEvent(
                    currentUser,
                  () => {
                    this.setState({ loginTrue: true,[e.target.id] :'' });
                  }
                );
              }
              else{
                alert("Wrong password");
              }
    }

    render(){

        if(this.state.loginTrue) return <Redirect to="/home"/>
        const color = {
            color:'#2BBFF5' 
        }
        return(
            <form class="form-control" onSubmit={this.handleSubmit} style={{backgroundColor:'transparent',height:'300px',border:'0px'}}>
            <h5 style={{color:'white'}}>
                Login
            </h5>
            <div className="input-field">
                <label htmlFor="username"  style={color}>UserName</label>
                <input type="text" id="username" onChange={this.handleChange} required/>
            </div>
           
            <div className="input-field">
                <label htmlFor="password"  style={color}>Password</label>
                <input type="password" id="password" onChange={this.handleChange} required/>
            </div>
            <div className="input-field">
                <button className="btn red lighten-1 z-depth" type="submit">Login</button>
            </div>
        </form>
        )
    }
}

const mapStateToProps = (state) => ({
    users : state.users  
  });
  
const mapDispatchToProps = {
    loginUserEvent,
    fetchUsers
  }

export default connect(mapStateToProps,mapDispatchToProps)(SigninForm)
