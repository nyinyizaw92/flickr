import React from 'react';
import {
  BrowserRouter as Router,
  Redirect,
  Route,
  Link
} from "react-router-dom";
import { connect } from 'react-redux';
import { fetchFiles } from '../../Actions/FileAction'
import { fetchUsers } from '../../Actions/UserActions'
import { deleteArticle } from '../../Actions/FileAction'
import CommentForm from  './CommentForm'

class ArticleDetailList extends React.Component{

    constructor(props){
      super(props);
      this.props.fetchFiles();
      this.props.fetchUsers();
      this.props.deleteArticle();
    }

    render(){
        const id = this.props.match.params.id;
        const articles = this.props.files;
        const users = this.props.users;
        const currentUser = this.props.currentUser;
        const currentArticle =  articles.find( item => item.id == id);
      
        if(currentArticle === undefined) return <div>404 - Content not found</div>
        
        // const author = users.find(obj => obj.id === currentArticle.created_by);
        let allowToDelete = false;
        if(currentUser){
          if(currentUser.id === currentArticle.author.id){
            allowToDelete = true;
          }
        }

     return (
        <React.Fragment>
          <br/>
        <h3>
          {currentArticle.title} by {currentArticle.author.username}
        </h3>        
        { allowToDelete && (
            <Link to={`/articles/delete/${currentArticle.id}`}>Delete</Link>
        ) }
         <hr />
        <CommentForm article =  {currentArticle}/>
        {
          currentArticle.comments == undefined ? "no comment":

          
          currentArticle.comments.map( (item,index) => <div key={index}>{item.comment} by {item.author.username}</div>)
        }

   
      </React.Fragment>
     );
    }
}

const mapStateToProps = state => ({
  files : state.files,
  users : state.users,
  currentUser : state.currentUser
})

const mapDispatchToProps = {
    fetchFiles,
  fetchUsers,
  deleteArticle
}

export default connect (mapStateToProps,mapDispatchToProps)(ArticleDetailList)