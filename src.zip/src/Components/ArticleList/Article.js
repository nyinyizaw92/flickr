import React from "react";
import {
  BrowserRouter as Router,
  Redirect,
  Route,
  Link
} from "react-router-dom";
import ArticleDetailList from "./ArticleDetailList";
import DeleteArticle from './DeleteArticle'

export default class Article extends React.Component {
  render() {
    const receive = this.props.article.author.email
   
    console.log('title',receive)
    return (
      <Router>
        <div class="container" >
          <div class="row" style={{width:'1200px'}}>
              <div class='col-sm-3'>
              <br/>
              <img src={this.props.article.url} style={{width:'150px',height:'150px'}} />
               <p> <Link to={"/articles/"+this.props.article.id}>{this.props.article.title} </Link></p>
        
              </div>
          </div>
        </div>
        <Route path="/articles/:id" exact component={ArticleDetailList} />
        <Route
              path="/articles/delete/:id"
              exact
              component={DeleteArticle}
            />
      </Router>
    );
  }
}
