import React from 'react'
import { connect } from 'react-redux'
import {
  BrowserRouter as Router,
  Redirect,
  Route,
  Link
} from "react-router-dom";
import { fetchFiles } from '../../Actions/FileAction'
import Article from './Article'
import ArticleDetailList from './ArticleDetailList'

class ArticleList extends React.Component{
    constructor(props){
        super(props);
        this.props.fetchFiles();

       
    }
    render(){
        const articles = this.props.files;
        console.log('filelist',articles)
        if(articles !== undefined){
            return articles.map((article, index) => {  
              return (
           
                <Router>
                  
              
                  <Article key={index} article={article} author={article.author} />
                  
                  <Route path="/articles/:id" component={ArticleDetailList} />
                </Router>
          
              )
             
          
             
            });
            // return(
            //   <h1>hello</h1>
            // )
          }
        return(
            <h1>Hi</h1>
        )
    }
}

const mapStateToProps = (state) => ({
    files:state.files
  });
  

const mapDispatchToProps = {
    fetchFiles
}
export default connect(mapStateToProps,mapDispatchToProps)(ArticleList)