import React from 'react'
import AddImage from './AddImage'
import { connect } from 'react-redux'
import {loginUserEvent} from '../../Actions/UserActions'

class UploadImage extends React.Component{
    constructor(props){
        super(props);
     
    }
    render(){
        const login = this.props.currentUser;
        console.log('cc',login);
        return(
            <div class="container">
                <div class="row">
                <div class="col-sm-6">
                    <h5>Add your image</h5>
                    <AddImage user={this.props.currentUser}/>
                </div>
              
           </div>
            </div>
           
        )
    }
}

const mapStateToProps = state =>({
    currentUser:state.currentUser
})


export default connect(mapStateToProps)(UploadImage)